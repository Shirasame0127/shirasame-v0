var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/images/direct-upload/route.js")
R.c("server/chunks/[root-of-the-server]__04561154._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/b52db__next-internal_server_app_api_images_direct-upload_route_actions_de4c5f61.js")
R.m(71146)
module.exports=R.m(71146).exports
