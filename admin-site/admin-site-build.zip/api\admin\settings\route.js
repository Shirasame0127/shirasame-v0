var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/route.js")
R.c("server/chunks/[root-of-the-server]__ed42f8f8._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_admin_settings_route_actions_956df88a.js")
R.m(26444)
module.exports=R.m(26444).exports
