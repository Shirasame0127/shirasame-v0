var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/check-email/route.js")
R.c("server/chunks/[root-of-the-server]__3786cc99._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_check-email_route_actions_3efaa382.js")
R.m(21373)
module.exports=R.m(21373).exports
