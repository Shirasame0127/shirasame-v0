var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__eefdbdaa._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_me_route_actions_c61f3a39.js")
R.m(47982)
module.exports=R.m(47982).exports
