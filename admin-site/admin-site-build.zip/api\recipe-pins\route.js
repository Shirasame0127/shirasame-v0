var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/recipe-pins/route.js")
R.c("server/chunks/[root-of-the-server]__69618b66._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_recipe-pins_route_actions_1532c4ee.js")
R.m(8967)
module.exports=R.m(8967).exports
