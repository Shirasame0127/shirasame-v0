var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/route.js")
R.c("server/chunks/[root-of-the-server]__ee471090._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_admin_products_route_actions_28035213.js")
R.m(69678)
module.exports=R.m(69678).exports
