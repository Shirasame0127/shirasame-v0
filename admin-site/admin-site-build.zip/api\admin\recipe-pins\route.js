var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/recipe-pins/route.js")
R.c("server/chunks/[root-of-the-server]__d395026f._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/b52db__next-internal_server_app_api_admin_recipe-pins_route_actions_a0c55ed1.js")
R.m(42269)
module.exports=R.m(42269).exports
