var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/session/route.js")
R.c("server/chunks/[root-of-the-server]__4864ad6a._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_session_route_actions_a4ba7709.js")
R.m(61333)
module.exports=R.m(61333).exports
