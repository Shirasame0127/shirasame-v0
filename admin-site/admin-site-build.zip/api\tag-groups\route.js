var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tag-groups/route.js")
R.c("server/chunks/[root-of-the-server]__ad241b06._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_tag-groups_route_actions_dff9440a.js")
R.m(25924)
module.exports=R.m(25924).exports
