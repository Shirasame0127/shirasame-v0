var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/recipes/route.js")
R.c("server/chunks/[root-of-the-server]__801a5874._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_admin_recipes_route_actions_e4b84a40.js")
R.m(54000)
module.exports=R.m(54000).exports
