var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__398b29dc._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_products_route_actions_eb316804.js")
R.m(47806)
module.exports=R.m(47806).exports
