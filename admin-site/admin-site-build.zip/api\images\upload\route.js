var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/images/upload/route.js")
R.c("server/chunks/[root-of-the-server]__bba1a32c._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_images_upload_route_actions_5a06b986.js")
R.m(4648)
module.exports=R.m(4648).exports
