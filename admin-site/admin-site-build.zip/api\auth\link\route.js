var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/link/route.js")
R.c("server/chunks/[root-of-the-server]__db55f167._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_link_route_actions_04187f4b.js")
R.m(5166)
module.exports=R.m(5166).exports
