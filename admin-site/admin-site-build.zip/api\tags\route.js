var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tags/route.js")
R.c("server/chunks/[root-of-the-server]__86482d5b._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_tags_route_actions_a38c7035.js")
R.m(72935)
module.exports=R.m(72935).exports
