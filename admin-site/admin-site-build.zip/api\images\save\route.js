var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/images/save/route.js")
R.c("server/chunks/[root-of-the-server]__548cd11d._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_images_save_route_actions_4bc14e47.js")
R.m(5536)
module.exports=R.m(5536).exports
