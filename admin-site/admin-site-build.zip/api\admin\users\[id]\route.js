var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__b72bd473._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_admin_users_[id]_route_actions_4a4ab272.js")
R.m(27026)
module.exports=R.m(27026).exports
