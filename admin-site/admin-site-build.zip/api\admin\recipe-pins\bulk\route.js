var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/recipe-pins/bulk/route.js")
R.c("server/chunks/[root-of-the-server]__6d594113._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/b52db__next-internal_server_app_api_admin_recipe-pins_bulk_route_actions_82c18367.js")
R.m(61178)
module.exports=R.m(61178).exports
