var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/debug/log/route.js")
R.c("server/chunks/[root-of-the-server]__7d18716c._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_debug_log_route_actions_6409ffe7.js")
R.m(94040)
module.exports=R.m(94040).exports
