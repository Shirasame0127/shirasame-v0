var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/whoami/route.js")
R.c("server/chunks/[root-of-the-server]__421a5d71._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_whoami_route_actions_6da0a830.js")
R.m(9464)
module.exports=R.m(9464).exports
