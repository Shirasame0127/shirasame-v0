var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/amazon-sale-schedules/route.js")
R.c("server/chunks/[root-of-the-server]__2200bb87._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/b52db__next-internal_server_app_api_amazon-sale-schedules_route_actions_8d51d4ae.js")
R.m(82704)
module.exports=R.m(82704).exports
