var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/site-settings/route.js")
R.c("server/chunks/[root-of-the-server]__82df4115._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_site-settings_route_actions_4b93eabe.js")
R.m(28729)
module.exports=R.m(28729).exports
