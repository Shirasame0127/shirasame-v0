globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/fcc5077be1292c90.js",
    "static/chunks/dee0ffdd6a5dbbdf.js",
    "static/chunks/7182ed423e41d173.js",
    "static/chunks/922932c1a6aeceec.js",
    "static/chunks/5ce16d5c79574208.js",
    "static/chunks/turbopack-a057ca5fd5d1bb95.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];