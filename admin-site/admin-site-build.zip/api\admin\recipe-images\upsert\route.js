var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/recipe-images/upsert/route.js")
R.c("server/chunks/[root-of-the-server]__44dde7b2._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/b52db__next-internal_server_app_api_admin_recipe-images_upsert_route_actions_37aeb462.js")
R.m(66070)
module.exports=R.m(66070).exports
