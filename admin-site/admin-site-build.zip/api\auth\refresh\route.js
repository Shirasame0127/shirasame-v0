var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/refresh/route.js")
R.c("server/chunks/[root-of-the-server]__ab1ba979._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_refresh_route_actions_6b06659e.js")
R.m(50069)
module.exports=R.m(50069).exports
