var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/recipes/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__57ff6da5._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/b52db__next-internal_server_app_api_admin_recipes_[id]_route_actions_3e380ccc.js")
R.m(26040)
module.exports=R.m(26040).exports
