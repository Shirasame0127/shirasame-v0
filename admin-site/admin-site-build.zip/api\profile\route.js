var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/route.js")
R.c("server/chunks/[root-of-the-server]__ceb2cbc5._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_profile_route_actions_f08419c2.js")
R.m(69537)
module.exports=R.m(69537).exports
