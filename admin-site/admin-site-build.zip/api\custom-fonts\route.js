var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/custom-fonts/route.js")
R.c("server/chunks/[root-of-the-server]__bfa29c25._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_custom-fonts_route_actions_62b42f70.js")
R.m(71336)
module.exports=R.m(71336).exports
