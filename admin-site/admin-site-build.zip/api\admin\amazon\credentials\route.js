var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/amazon/credentials/route.js")
R.c("server/chunks/[root-of-the-server]__6c7a19c8._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/b52db__next-internal_server_app_api_admin_amazon_credentials_route_actions_4fca77c0.js")
R.m(19507)
module.exports=R.m(19507).exports
