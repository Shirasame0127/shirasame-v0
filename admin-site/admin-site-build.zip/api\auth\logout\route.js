var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__94d57b8b._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_logout_route_actions_0e8a5dd8.js")
R.m(22747)
module.exports=R.m(22747).exports
