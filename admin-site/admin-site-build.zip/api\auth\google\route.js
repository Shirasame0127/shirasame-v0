var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/route.js")
R.c("server/chunks/[root-of-the-server]__8035ca1f._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_auth_google_route_actions_87344f28.js")
R.m(59043)
module.exports=R.m(59043).exports
