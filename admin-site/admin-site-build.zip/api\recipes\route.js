var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/recipes/route.js")
R.c("server/chunks/[root-of-the-server]__e73402c3._.js")
R.c("server/chunks/[root-of-the-server]__91237911._.js")
R.c("server/chunks/admin-site__next-internal_server_app_api_recipes_route_actions_79847de0.js")
R.m(80434)
module.exports=R.m(80434).exports
